---
id: Settings
title: Configuration settings
sidebar_label: Settings
---

