---
id: API_Doxygen
title: Reference
sidebar_label: Reference
---
[**The LogDevice C++ API reference is generated using Doxygen**](../api/annotated.html).
