The tutorial in TensorFlow related to Neural Network architectures.
