
# Run training.
python test_classifier.py \
  --batch_size=512 \
  --allow_soft_placement

