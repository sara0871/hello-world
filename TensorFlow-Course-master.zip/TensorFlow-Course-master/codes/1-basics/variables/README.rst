==========
Variables
==========

This source code is dedicated to define and initialize variables.

   
--------------------------------
How to run the code in Terminal?
--------------------------------

    
Please root to the ``code/`` directory and run the python script as the general form of below:

.. code:: shell
    
    python [python_code_file.py]
    

As an example the code can be executed as follows:

.. code:: shell
    
    python variable.py

----------------------------
How to run the code in IDEs?
----------------------------

Since the code is ready-to-go, as long as the TensorFlow can be called in the IDE editor(Pycharm, Spyder,..), the code can be executed successfully.

 



