Web Console
===

Arthas目前支持Web Console，用户在attach成功之后，可以直接访问：[http://localhost:8563/](http://localhost:8563/)。

可以填入IP，远程连接其它机器上的arthas。

![web console](_static/web-console-local.png)

后续更多Web Console功能支持，请到issue下留言：[https://github.com/alibaba/arthas/issues/15](https://github.com/alibaba/arthas/issues/15)