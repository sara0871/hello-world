package com.alibaba.arthas;

public enum Type {
    RUN, STOP;
}
