Freedesktop Plugin
==================

The ``freedesktop`` plugin created .directory files in your album folders.
This plugin is now deprecated and replaced by the :doc:`/plugins/thumbnails`
with the `dolphin` option enabled.
