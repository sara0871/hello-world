Reference
=========

This section contains reference materials for various parts of beets. To get
started with beets as a new user, though, you may want to read the
:doc:`/guides/main` guide first.

.. toctree::
   :maxdepth: 2

   cli
   config
   pathformat
   query
