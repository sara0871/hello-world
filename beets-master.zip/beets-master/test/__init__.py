# -*- coding: utf-8 -*-

# Make python -m testall.py work.

from __future__ import division, absolute_import, print_function
