export default { detail: 'Not found.' };
