export default { amount_base: 0.69059602, amount_quote: 100001.0, fetching: false };
