/** Automatically generated file. DO NOT MODIFY */
package com.tesis.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}