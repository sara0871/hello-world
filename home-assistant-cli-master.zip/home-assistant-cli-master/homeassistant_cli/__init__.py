"""Init file for Home Assistant CLI (hass-cli)."""
