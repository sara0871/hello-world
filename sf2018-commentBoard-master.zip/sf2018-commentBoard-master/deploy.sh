git pull
npm install
node index.js | ./node_modules/.bin/bunyan -o short -l trace