cd ..
git pull
cd server
cp -f get-history-posts.php /home/wwwroot/sf2018-api/index.php