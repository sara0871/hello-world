Lux-qt: Qt5 GUI for Lux
===============================

Linux
-------
https://github.com/CoinProjects/Lux/blob/master/doc/build-unix.md

Windows
--------
https://github.com/CoinProjects/Lux/blob/master/doc/build-msw.md

Mac OS X
--------
https://github.com/CoinProjects/Lux/blob/master/doc/build-osx.md
