Lux Smart Constract Instruction
================================
This guide will show you how to creat a contract using lux-qt wallet

 1. Open required smart contract on http://remix.ethereum.org
 
 2. Press "Start to compile" button
 
 3. After smart contract has finished compiling - press "Details" button
 
 ![Smartcontract1](https://github.com/216k155/lux/blob/SC-Consensus/doc/img/smartcontract1.png)
 
 4. In opened window one should copy contains of "objects" filed (it is compiled smart contract bytecode)
  
 5. One should copy ABI from this very window as well as well
     6,7) Paste Bytecode and ABI on "Create Smart Contract" tab to respective fields
  
![Smartcontract2](https://github.com/216k155/lux/blob/SC-Consensus/doc/img/smartcontract2.png)
  
 6. Fill constructior fileds of smart contract (if there are ones. if there is no smart contract - there will be no constructor and this field will be empty)
    
 7. Set optional fields if necessary
    
 ![Smartcontract3](https://github.com/216k155/lux/blob/SC-Consensus/doc/img/smartcontract3.png)
  
 8. Press "CreateContract" button
      
 9. After transaction with smart contract is created successfully - window with smart contract info will open
      
 ![Smartcontract4](https://github.com/216k155/lux/blob/SC-Consensus/doc/img/smartcontract4.png)
  
 ![Smartcontract5](https://github.com/216k155/lux/blob/SC-Consensus/doc/img/smartcontract5.png)