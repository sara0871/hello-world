PWD=`pwd`
echo "PWD:$PWD"
ME=`pwd | sed 's!.*/\(.*\)/LUX!\1!'`
echo "ME:$ME"
