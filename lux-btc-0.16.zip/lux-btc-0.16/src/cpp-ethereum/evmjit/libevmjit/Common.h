#pragma once

#include <cstdint>

namespace dev
{
namespace evmjit
{

using byte = uint8_t;
using code_iterator = byte const*;

#define UNTESTED assert(false)

}
}
