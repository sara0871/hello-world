#if defined(_MSC_VER)
	#pragma warning(push)
	#pragma warning(disable: 4267 4244 4800 4624 4141 4291 4146)
#endif
