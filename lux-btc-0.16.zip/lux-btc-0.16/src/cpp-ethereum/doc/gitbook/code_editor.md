# Code Editor

This editor provides basic functionalities of a code editor.

 - In Solidity or JavaScript mode, an autocompletion plugin is available (Ctrl + Space).

 - Increasing/decreasing the font size (Ctrl +, Ctrl -)
 
 - In Solidity mode, you can display the gas estimation (Tools -> Display Gas Estimation). This will highlight all statements which requires a minimum amount of gas. Color turns to red if the gas required becomes important.
It will also display the max execution cost of a transaction (for each function).



