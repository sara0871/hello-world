# Mix

The IDE Mix is intended to help you as a developer to create, debug and deploy contracts and dapps (both contracts backend and frontend). 

Start by creating a new project that consists of 
* contracts
* html files 
* JavaScript files 
* style files
* image files 

