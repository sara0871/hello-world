Sample configuration files for:

SystemD: luxd.service
Upstart: luxd.conf
OpenRC:  luxd.openrc
         luxd.openrcconf
CentOS:  luxd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
