package com.kickstarter.models;

/**
 * A class with no values.
 */
public enum Empty {
  INSTANCE;

  public static Empty get() {
    return INSTANCE;
  }
}
