package com.kickstarter.libs.qualifiers;

import javax.inject.Qualifier;

@Qualifier
public @interface ActivitySamplePreference {
}
